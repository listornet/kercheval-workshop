Netlify static site. Slide 3 now uses the same full-bleed image and text overlay layout as slides 1 and 2 on mobile. Slide 4 retains its distinct montage and chart layout. Upload this ZIP to Netlify.
